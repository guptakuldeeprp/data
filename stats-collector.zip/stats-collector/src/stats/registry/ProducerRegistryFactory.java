package stats.registry;

import stats.core.plugin.PluginRepository;

public class ProducerRegistryFactory {

	/**
	 * The instance of the producer registry impl.
	 */
	private static final ProducerRegistry instance = new ProducerRegistryImpl();

	static {
		init();
	}

	/**
	 * Initializes the registry. If we are not in junit mode, start built-in
	 * producers.
	 */
	private static void init() {

		// ensure plugins are loaded.
		PluginRepository.getInstance();
	}

	/**
	 * Returns the IProducerRegistry singleton instance.
	 * 
	 * @return
	 */
	public static final ProducerRegistry getProducerRegistryInstance() {
		return instance;
	}

	/**
	 * Resets the registry, useable for unit tests. Note this method doesn't
	 * stop producers from running (if the are running) hence it shouldn't be
	 * used in production environment.
	 */
	public static final void reset() {
		instance.reset();
	}

}
