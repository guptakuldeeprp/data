package stats.registry;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import stats.core.producer.StatsProducer;

@SuppressWarnings("rawtypes")
public class ProducerRegistryImpl implements ProducerRegistry {

	private Object lock = new Object();

	private static final Log logger = LogFactory.getLog(ProducerRegistryImpl.class);

	private final Map<String, WeakReference<StatsProducer>> registry = new HashMap<String, WeakReference<StatsProducer>>();

	@Override
	public StatsProducer registerProducer(StatsProducer producer) {
		String producerToString = null;
		try {
			producerToString = producer.toString();
		} catch (Exception e) {
			producerToString = "Illegal to string method: " + e.getMessage() + ", " + e.getClass();
		}
		if (logger.isTraceEnabled())
			logger.trace("Registry register producer: " + producer.getProducerId() + " / " + producerToString);

		WeakReference<StatsProducer> previousRef = registry.get(producer.getProducerId());
		// WeakReference<StatsProducer> previousRef =
		// registry.put(producer.getProducerId(), new
		// WeakReference<StatsProducer>(producer));
		StatsProducer previous = previousRef == null ? null : previousRef.get();
		if (previous != null) {
			logger.trace("Under this name a producer was already registered: " + previous);
			return previous;
		} else {

			synchronized (lock) {
				if (registry.containsKey(producer.getProducerId()))
					return registry.get(producer.getProducerId()).get();
				registry.put(producer.getProducerId(), new WeakReference<StatsProducer>(producer));
				return producer;
			}
		}

		/*
		 * WeakReference<StatsProducer> previousRef =
		 * registry.putIfAbsent(producer.getProducerId(), new
		 * WeakReference<StatsProducer>(producer)); StatsProducer previous =
		 * previousRef == null ? null : previousRef.get(); if (previous != null)
		 * { logger.info("Under this name a producer was already registered: " +
		 * previous); return previous; }
		 * 
		 * return producer;
		 */

	}

	@Override
	public void unregisterProducer(StatsProducer producer) {
		registry.remove(producer.getProducerId());
	}

	@Override
	public StatsProducer getProducer(String producerId) {
		if (producerId == null)
			throw new IllegalArgumentException("Null is not a valid producerId");
		synchronized (lock) {
			WeakReference<StatsProducer> ref = registry.get(producerId);
			return ref == null ? null : ref.get();
		}
	}

	@Override
	public void cleanup() {
		ArrayList<WeakReference<StatsProducer>> producerReferences = new ArrayList<WeakReference<StatsProducer>>();
		producerReferences.addAll(registry.values());
		for (WeakReference<StatsProducer> p : producerReferences) {
			try {
				if (p.get() != null)
					unregisterProducer(p.get());
			} catch (Exception e) {
				logger.warn("can't unregister producer " + p, e);
			}
		}

	}

	@Override
	public Collection<StatsProducer> getProducers() {
		ArrayList<StatsProducer> ret = new ArrayList<StatsProducer>();
		for (WeakReference<StatsProducer> r : registry.values()) {
			if (r.get() != null)
				ret.add(r.get());
		}
		return ret;

	}

	@Override
	public void reset() {
		cleanup();
	}

	@Override
	public String toString() {
		return "ProducerRegistryImpl [registry=" + registry + "]";
	}

}
