package stats.registry;

import java.util.Collection;

import stats.core.producer.StatsProducer;

//TODO: Support listeners for registering and unregistering of producers. These listeners can be registered with the ProducerRegistry.
@SuppressWarnings("rawtypes")
public interface ProducerRegistry {

	StatsProducer registerProducer(StatsProducer producer);

	void unregisterProducer(StatsProducer producer);

	StatsProducer getProducer(String producerId) throws NoSuchProducerException;

	Collection<StatsProducer> getProducers();
	
	/**
	 * Cleans up the state
	 */
	void cleanup();
	
	/**
	 * cleans up and removes listeners as well
	 */
	void reset();

}
