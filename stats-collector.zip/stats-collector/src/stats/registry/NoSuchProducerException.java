package stats.registry;

public class NoSuchProducerException extends Exception {

	public NoSuchProducerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchProducerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchProducerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSuchProducerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
