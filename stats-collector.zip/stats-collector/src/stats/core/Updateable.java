package stats.core;

public interface Updateable {
	
	void update();

}
