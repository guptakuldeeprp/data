package stats.core.snapshot;

public interface SnapshotConsumer {
	void consumeSnapshot(ProducerSnapshot snapshot);
}
