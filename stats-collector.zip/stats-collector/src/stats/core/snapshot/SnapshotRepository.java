package stats.core.snapshot;

 import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import stats.core.producer.StatsProducer;
import stats.registry.ProducerRegistry;
import stats.registry.ProducerRegistryFactory;


//TODO: A basic implementation. In future, we need to support producers updating stats at different intervals
public final class SnapshotRepository {
	
	
	private static final Log logger = LogFactory.getLog(SnapshotRepository.class);
	
	private static final SnapshotRepository instance = new SnapshotRepository();

	private final List<SnapshotConsumer> consumers = new CopyOnWriteArrayList<SnapshotConsumer>();

	// TODO: Implement a ProducerRegistryAPI for producer monitoring. This API
	// will be an extra layer of abstraction for clients. It shall also provide
	// for more robust Thread safety. Use ProducerRegistryAPI here.
	private ProducerRegistry producerRegistry;

	private SnapshotRepository() {
		producerRegistry = ProducerRegistryFactory.getProducerRegistryInstance();
	}

	public static SnapshotRepository getInstance() {
		return instance;
	}

	/**
	 * Provided for external invocation. Ideally, as and when intervals are
	 * updated, the snapshots should be taken.
	 **/
	public void takeSnapshot() {
		if (consumers.size()==0)
			return;
		Collection<StatsProducer> producers = producerRegistry.getProducers();
		if (producers.size()==0)
			return;
		Iterator<StatsProducer> producersItr = producers.iterator();
		while(producersItr.hasNext()) {
			StatsProducer<?> producer = producersItr.next();
			ProducerSnapshot snapshot = SnapshotCreator.createSnapshot(producer,"");
			
			for (SnapshotConsumer consumer : consumers){
				try{
					consumer.consumeSnapshot(snapshot);
				}catch(Exception e){
					logger.warn("consumer "+consumer+" failed to process snapshot. "+e.getMessage(), e);
				}
			}
			
			if(producer.unregisterAfterSnapshot())
				producerRegistry.unregisterProducer(producer);
		}
	}

	/**
	 * Adds a new snapshot consumer.
	 * 
	 * @param consumer
	 */
	public void addConsumer(SnapshotConsumer consumer) {
		if (consumers.contains(consumer))
			consumers.remove(consumer);
		consumers.add(consumer);
	}

	/**
	 * Removes a previously registered consumer.
	 * 
	 * @param consumer
	 */
	public void removeConsumer(SnapshotConsumer consumer) {
		consumers.remove(consumer);
	}

}
