package stats.core.snapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProducerSnapshot {
	/**
	 * Associated producer id.
	 */
	private String producerId;
	/**
	 * Category of the associated producer.
	 */
	private String category;
	/**
	 * Subsystem of the associated producer.
	 */
	private String subsystem;
	/**
	 * Name of the interval.
	 */
	private String intervalName;

	/**
	 * Name of the class of the used stat.
	 */
	private String statClassName;

	private long timestamp = System.currentTimeMillis();

	// private Map<String, StatSnapshot> stats = new HashMap<String,
	// StatSnapshot>();

	private List<StatSnapshot> stats = new ArrayList<StatSnapshot>();

	public void setSubsystem(String subsystem) {
		this.subsystem = subsystem;
	}

	public String getProducerId() {
		return producerId;
	}

	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubsystem() {
		return subsystem;
	}

	public void addSnapshot(StatSnapshot snapshot) {
		// stats.put(snapshot.getName(), snapshot);
		stats.add(snapshot);
	}

	/*
	 * public Map<String, StatSnapshot> getStatSnapshots() { return stats; }
	 */

	public List<StatSnapshot> getStatSnapshots() {
		return stats;
	}

	public String getIntervalName() {

		return intervalName;
	}

	public void setIntervalName(String intervalName) {
		this.intervalName = intervalName;
	}

	@Override
	public String toString() {
		return "ProducerSnapshot [producerId=" + producerId + ", category=" + category + ", subsystem=" + subsystem
				+ ", intervalName=" + intervalName + ", statClassName=" + statClassName + ", timestamp=" + timestamp
				+ ", stats=" + stats + "]";
	}

	public StatSnapshot getStatSnapshot(String statName) {
		for (StatSnapshot stat : stats) {
			if (stat.getName().equals(statName))
				return stat;
		}
		return null;
		// return stats.get(statName);
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public String getStatClassName() {
		return statClassName;
	}

	public void setStatClassName(String statClassName) {
		this.statClassName = statClassName;
	}

}
