package stats.core.snapshot;

import java.util.List;

import stats.core.producer.StatsProducer;
import stats.core.stats.Stats;

public class SnapshotCreator {
	/**
	 * Creates a snapshot for a producer.
	 * 
	 * @param producer
	 * @param intervalName
	 * @return
	 */
	public static ProducerSnapshot createSnapshot(StatsProducer producer, String intervalName) {
		ProducerSnapshot ret = new ProducerSnapshot();
		ret.setCategory(producer.getCategory());
		ret.setSubsystem(producer.getSubsystem());
		ret.setProducerId(producer.getProducerId());
		ret.setIntervalName(intervalName);

		List<Stats> stats = producer.getStats();
		
		if (stats != null && stats.size() > 0)
			ret.setStatClassName(stats.get(0).getClass().getName());

		// optimization
		if (stats == null || stats.size() == 0)
			return ret;
		List<String> cachedValueNames = stats.get(0).getAvailableValueNames();

		for (Stats stat : stats) {
			ret.addSnapshot(createStatSnapshot(stat, intervalName, cachedValueNames));
		}

		return ret;
	}

	/**
	 * Creates a snapshot for one stat object.
	 * 
	 * @param stat
	 * @param intervalName
	 * @param valueNames
	 * @return
	 */
	private static StatSnapshot createStatSnapshot(Stats stat, String intervalName, List<String> valueNames) {
		StatSnapshot snapshot = new StatSnapshot(stat.getName());

		for (String valueName : valueNames) {
			snapshot.setValue(valueName, stat.getValueByNameAsString(valueName));
		}

		return snapshot;

	}
}
