package stats.core.snapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Snapshot implements Serializable {

	private static final long serialVersionUID = 9062355342322259027L;

	private SnapshotMetadata metaData;

	//private HashMap<String, HashMap<String, String>> stats = new HashMap<String, HashMap<String, String>>();
	
	List<Map<String, String>> stats = new ArrayList<Map<String, String>>();

	public Snapshot() {

	}

	public SnapshotMetadata getMetaData() {
		return metaData;
	}

	public void setMetaData(SnapshotMetadata metaData) {
		this.metaData = metaData;
	}

	/*public HashMap<String, HashMap<String, String>> getStats() {
		if (stats == null) {
			stats = new HashMap<String, HashMap<String, String>>();
		}
		return stats;
	}

	public void setStats(HashMap<String, HashMap<String, String>> stats) {
		this.stats = stats;
	}*/
	

	/*public void addSnapshotData(String name, HashMap<String, String> values) {
		stats.put(name, values);
	}*/
	
	public void addSnapshotData(Map<String, String> values) {
		stats.add(values);
	}

	public List<Map<String, String>> getStats() {
		return stats;
	}

	public void setStats(List<Map<String, String>> stats) {
		this.stats = stats;
	}

	/*public Map<String, String> getStatistics(String stat) {
	
		return stats.get(stat);
	}
	
	@JsonIgnore
	public List<String> getKeySet() {
		 
		return stats.keySet();
	}
*/
}
