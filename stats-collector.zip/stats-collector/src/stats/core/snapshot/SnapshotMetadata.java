package stats.core.snapshot;

import java.io.Serializable;

public class SnapshotMetadata implements Serializable{


	private static final long serialVersionUID = 1807482071376496524L;

	private String producerId;

	private String componentName;

	private String hostName;

	private String category;

	private String subsystem;

	private String statClassName;
	
	private String intervalName;

	public SnapshotMetadata() {

	}

	public String getProducerId() {
		return producerId;
	}

	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubsystem() {
		return subsystem;
	}

	public void setSubsystem(String subsystem) {
		this.subsystem = subsystem;
	}

	public String getStatClassName() {
		return statClassName;
	}

	public void setStatClassName(String statClassName) {
		this.statClassName = statClassName;
	}
	
	public String getIntervalName() {
		return intervalName;
	}

	public void setIntervalName(String intervalName) {
		this.intervalName = intervalName;
	}


	@Override
	public String toString() {
		return "SnapshotMetadata [producerId=" + producerId + ", componentName=" + componentName + ", hostName="
				+ hostName + ", category=" + category + ", subsystem=" + subsystem + ", statClassName=" + statClassName
				+ "]";
	}
}
