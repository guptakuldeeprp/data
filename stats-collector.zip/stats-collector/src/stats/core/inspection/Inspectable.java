package stats.core.inspection;



public interface Inspectable {
	/**
	 * Returns the creation info of this object.
	 * @return creation info object
	 */
	CreationInfo getCreationInfo(); 
}