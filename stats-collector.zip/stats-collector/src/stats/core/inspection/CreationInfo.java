package stats.core.inspection;

import java.util.Arrays;

/**
 * An object that stores the info about the creation of another object. As for
 * now the timestamp of the creation is stored along with the stacktrace.
 */
public class CreationInfo {
	/**
	 * Timestamp of the creation.
	 */
	private long timestamp;
	/**
	 * Stack trace of the creation.
	 */
	private StackTraceElement[] stackTrace;

	public CreationInfo(StackTraceElement[] aStackTrace) {
		timestamp = System.currentTimeMillis();
		stackTrace = Arrays.copyOf(aStackTrace, aStackTrace.length);
	}

	public StackTraceElement[] getStackTrace() {
		return Arrays.copyOf(stackTrace, stackTrace.length);
	}

	public void setStackTrace(StackTraceElement[] stackTrace) {
		this.stackTrace = Arrays.copyOf(stackTrace, stackTrace.length);
	}

	public long getTimestamp() {
		return timestamp;
	}
}
