package stats.core.plugin;

import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.configureme.ConfigurationManager;

import stats.config.plugin.RestConnectorConfig;
import stats.core.snapshot.Snapshot;
import stats.utils.JsonHelper;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;

public class RestConnector extends AbstractConnectorPlugin {

	private static final Log logger = LogFactory.getLog(RestConnector.class);

	protected RestConnectorConfig connectorConfig;

	private volatile Client client;

	@Override
	public void setConfigurationName(String configurationName) {
		connectorConfig = new RestConnectorConfig();
		ConfigurationManager.INSTANCE.configureAs(connectorConfig, configurationName);
		logger.debug("Config: " + connectorConfig);
		client = getClient();
	}

	private Client getClient() {
		Client client = Client.create(getClientConfig());
		return client;
	}

	protected ClientConfig getClientConfig() {
		ClientConfig clientConfig = new DefaultClientConfig();
		
		clientConfig.getClasses().add(JacksonJsonProvider.class);
		clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
		return clientConfig;
	}

	protected URI getBaseURI() {
		return UriBuilder.fromUri("http://" + connectorConfig.getHost() + connectorConfig.getResourcePath())
				.port(connectorConfig.getPort()).build();
	}

	@Override
	protected void sendData(Snapshot snapshot) {
		WebResource resource = client.resource(getBaseURI());
        //resource.accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(snapshot);
        resource.type(MediaType.TEXT_PLAIN).post(JsonHelper.getJsonString(snapshot));

	}

}
