package stats.core.plugin;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.configureme.ConfigurationManager;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;

import stats.config.plugin.InfluxdbConfig;
import stats.core.snapshot.ProducerSnapshot;
import stats.core.snapshot.Snapshot;
import stats.core.snapshot.SnapshotRepository;

public class InfluxdbPlugin extends AbstractConnectorPlugin {

	private static final Log logger = LogFactory.getLog(InfluxdbPlugin.class);

	protected InfluxdbConfig influxdbConfig;
	protected InfluxDB influxDB;
	

	@Override
	public void consumeSnapshot(ProducerSnapshot snapshot) {
		
	}

	@Override
	public void setConfigurationName(String configurationName) {
		influxdbConfig = new InfluxdbConfig();
		ConfigurationManager.INSTANCE.configureAs(influxdbConfig, configurationName);
	}

	@Override
	public void initialize() {
		SnapshotRepository.getInstance().addConsumer(this);

		influxDB = InfluxDBFactory.connect(influxdbConfig.getUrl(), influxdbConfig.getUsername(),
				influxdbConfig.getPassword());
		String dbName = influxdbConfig.getDbname();
		influxDB.createDatabase(dbName);
		

	}

	@Override
	public void deInitialize() {
		SnapshotRepository.getInstance().removeConsumer(this);
	}

	@Override
	protected void sendData(Snapshot snapshot) {
		
	}

}
