package stats.core.plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import stats.config.StatsConfigHolder;
import stats.config.plugin.PluginConfig;
import stats.config.plugin.PluginsConfig;

public class PluginRepository {

	private static final Log logger = LogFactory.getLog(PluginRepository.class);
	private static final PluginRepository instance = new PluginRepository();
	static {
		instance.setup();
	}


	private ConcurrentMap<String, Plugin> plugins = new ConcurrentHashMap<String, Plugin>();

	/**
	 * Cached configs.
	 */
	private ConcurrentMap<String, PluginConfig> configs = new ConcurrentHashMap<String, PluginConfig>();

	/**
	 * Returns plugin repository singleton instance.
	 * 
	 * @return
	 */
	public static final PluginRepository getInstance() {
		return instance;
	}

	private void setup() {
		PluginsConfig config = StatsConfigHolder.getConfiguration().getPluginsConfig();
		if (config.getPlugins() == null)
			return;
		for (PluginConfig pc : config.getPlugins()) {
			logger.info("Loading plugin " + pc);
			// logger.info("Loading plugin ");
			try {
				Class<?> pluginClazz = Class.forName(pc.getClassName());
				if (pluginClazz == null) {
					System.out.println("context class loader: "
							+ Thread.currentThread().getContextClassLoader().toString());
					throw new InstantiationException("could not get plugin class " + pc.getClassName()
							+ " by classloader " + getClass().getClassLoader().toString());
				}
				Plugin plugin = Plugin.class.cast(Class.forName(pc.getClassName()).newInstance());

				plugin.setConfigurationName(pc.getConfigurationName());
				addPlugin(pc.getName(), plugin, pc);
			} catch (InstantiationException e) {
				logger.warn("Couldn't initialize plugin " + pc, e);
			} catch (IllegalAccessException e) {
				logger.warn("Couldn't initialize plugin " + pc, e);
			} catch (ClassNotFoundException e) {
				logger.warn("Couldn't initialize plugin " + pc, e);
			}

		}
	}

	/**
	 * Adds a new loaded plugin.
	 * 
	 * @param name
	 *            name of the plugin for ui.
	 * @param plugin
	 *            the plugin instance.
	 * @param config
	 *            plugin config which was used to load the plugin.
	 */
	public void addPlugin(String name, Plugin plugin, PluginConfig config) {
		plugins.put(name, plugin);
		try {
			plugin.initialize();
			configs.put(name, config);
		} catch (Exception e) {
			logger.warn("couldn't initialize plugin " + name + " - " + plugin + ", removing", e);
			plugins.remove(name);
		}
	}

	/**
	 * Removes a plugin. This call will call deInitialize on the plugin. The
	 * plugin is responsible to free all used resources and un-register itself
	 * from listening.
	 * 
	 * @param name
	 *            name of the plugin.
	 */
	public void removePlugin(String name) {
		configs.remove(name);
		Plugin plugin = plugins.remove(name);
		if (plugin == null) {
			logger.warn("Trying to remove not registered plugin " + name);
			return;
		}
		try {
			plugin.deInitialize();
		} catch (Exception e) {
			logger.warn("Couldn't de-initialize plugin " + name + " - " + plugin, e);
		}
	}

	/**
	 * Returns the names of the active plugins.
	 * 
	 * @return
	 */
	public List<String> getPluginNames() {
		ArrayList<String> ret = new ArrayList<String>();
		ret.addAll(plugins.keySet());
		return ret;
	}

	/**
	 * Returns loaded plugin by name.
	 * 
	 * @param name
	 * @return
	 */
	public Plugin getPlugin(String name) {
		return plugins.get(name);
	}

	/**
	 * Returns pluginconfig for the loaded plugin.
	 * 
	 * @param name
	 * @return
	 */
	public PluginConfig getConfig(String name) {
		return configs.get(name);
	}

}
