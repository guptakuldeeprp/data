package stats.core.plugin;

import dnl.utils.text.table.TextTable;
import stats.core.snapshot.ProducerSnapshot;
import stats.core.snapshot.SnapshotConsumer;
import stats.core.snapshot.SnapshotRepository;
import stats.core.snapshot.StatSnapshot;
import stats.core.stats.ServiceStats;
import stats.utils.JsonHelper;

public class ConsolePlugin implements Plugin, SnapshotConsumer {

	private String configurationName;

	@Override
	public void setConfigurationName(String configurationName) {
		this.configurationName = configurationName;
	}

	@Override
	public void initialize() {
		SnapshotRepository.getInstance().addConsumer(this);
	}

	@Override
	public void deInitialize() {
		SnapshotRepository.getInstance().removeConsumer(this);

	}

	@Override
	public void consumeSnapshot(ProducerSnapshot snapshot) {

		if (snapshot.getStatClassName().equals(ServiceStats.class.getName())) {
		System.out.println("+---------------- Producer metadata -----------------+");
		System.out.println();
		System.out.println("\tCategory: " + snapshot.getCategory());
		System.out.println("\tSubsystem: " + snapshot.getSubsystem());
		System.out.println("\tId: " + snapshot.getProducerId());
		System.out.println("\tStat Class Name: " + snapshot.getStatClassName());
		System.out.println();
		System.out.println("+----------------------------------------------------+");
			String columns[] = new String[] { "className","methodName", "startTime", "endTime", "total", "perc" };
			Object[][] data = new Object[snapshot.getStatSnapshots().size()][columns.length];
			long start = Long.parseLong(snapshot.getStatSnapshots().get(0).getValue("startTime"));
			long end = Long.parseLong(snapshot.getStatSnapshots().get(snapshot.getStatSnapshots().size() - 1)
					.getValue("endTime"));
			long total = end - start;
			for (int i = 0; i < snapshot.getStatSnapshots().size(); i++) {
				StatSnapshot ssnap = snapshot.getStatSnapshots().get(i);
				Object[] row = data[i];
				row[0] = ssnap.getValue("className");
				row[1] = ssnap.getValue("methodName");
				long s = Long.parseLong(ssnap.getValue("startTime"));
				long e = Long.parseLong(ssnap.getValue("endTime"));
				row[2] = s;
				row[3] = e;
				row[4] = e - s;
				row[5] = (e - s) / (double)total * 100.0D;
			}

			TextTable tt = new TextTable(columns, data);
			
			tt.printTable();
		} else {
			System.out.println(JsonHelper.getJsonString(snapshot));
		}
	}
}
