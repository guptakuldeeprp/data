package stats.core.plugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import stats.core.snapshot.ProducerSnapshot;
import stats.core.snapshot.Snapshot;
import stats.core.snapshot.SnapshotConsumer;
import stats.core.snapshot.SnapshotMetadata;
import stats.core.snapshot.SnapshotRepository;
import stats.core.snapshot.StatSnapshot;
import stats.utils.NetUtils;

/**
 * A plugin which connects to remote systems using different protocols for
 * sending snapshot data.
 * 
 * @author kuldeep.gupta
 *
 */
public abstract class AbstractConnectorPlugin implements Plugin, SnapshotConsumer {

	//private String componentName = "app";

	private String host;

	private static final Log logger = LogFactory.getLog(AbstractConnectorPlugin.class);

	@Override
	public void consumeSnapshot(ProducerSnapshot coreSnapshot) {
		Snapshot centralSnapshot = makeSnapshot(coreSnapshot);
		try {
			sendData(centralSnapshot);
		} catch (Exception e) {
			logger.error(this.getClass().getSimpleName() + ".sendData() failed", e);
		}
	}

	public AbstractConnectorPlugin() {
		try {
			host = NetUtils.getShortComputerName();
		} catch (Exception ignored) {
		}
		if (host == null)
			host = "unknown";
	}

	protected Snapshot makeSnapshot(ProducerSnapshot coreSnapshot) {

		Snapshot centralSnapshot = new Snapshot();

		SnapshotMetadata metaData = new SnapshotMetadata();
		metaData.setProducerId(coreSnapshot.getProducerId());
		metaData.setCategory(coreSnapshot.getCategory());
		metaData.setSubsystem(coreSnapshot.getSubsystem());

		// defaults to vertical-classification#horizontal-classification
		// sub-classes may chose to change it.
		metaData.setComponentName(coreSnapshot.getSubsystem() + "#" + coreSnapshot.getCategory());
		metaData.setHostName(host);
		metaData.setIntervalName(coreSnapshot.getIntervalName());

		// metaData.setCreationTimestamp(coreSnapshot.getTimestamp());
		metaData.setStatClassName(coreSnapshot.getStatClassName());
		centralSnapshot.setMetaData(metaData);

		List<StatSnapshot> coreStatSnapshots = coreSnapshot.getStatSnapshots();
		for (StatSnapshot coreStatSnapshot : coreStatSnapshots) {
			centralSnapshot.addSnapshotData(coreStatSnapshot.getValues());
		}

		/*
		 * Map<String, StatSnapshot> coreStatSnapshots =
		 * coreSnapshot.getStatSnapshots(); for (Map.Entry<String, StatSnapshot>
		 * coreStatSnapshot : coreStatSnapshots.entrySet()) {
		 * centralSnapshot.addSnapshotData(coreStatSnapshot.getKey(), new
		 * HashMap<String, String>(coreStatSnapshot .getValue().getValues())); }
		 */
		return centralSnapshot;

	}

	@Override
	public void initialize() {
		SnapshotRepository.getInstance().addConsumer(this);
	}

	@Override
	public void deInitialize() {
		SnapshotRepository.getInstance().removeConsumer(this);
	}

	protected abstract void sendData(Snapshot snapshot);
}
