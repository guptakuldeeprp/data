package stats.core.producer;

import java.util.List;

import stats.core.stats.Stats;


public interface StatsProducer <S extends Stats> {

	/**
	 * Name for the builtin system registration.
	 */
	public static final String SUBSYSTEM_BUILTIN = "builtin";

	/**
	 * Returns the list of all stats.
	 * 
	 * @return all stats this producer produces / generates.
	 */
	List<S> getStats();

	/**
	 * Returns the meaningful id of this producer. This should be something like a class or
	 * interface name.
	 * 
	 * @return a string which provides unique identification of this producer, i.e. the class name
	 *         or a readable form of it.
	 */
	String getProducerId();

	/**
	 * Returns the category of this producer. A typical category is something like servlet, action,
	 * service or dao. The categories are used to group different StatsProducer to get overview over
	 * a certain layer in the application, i.e. show me all action.
	 * 
	 * @return the id of the category the producer belongs to.
	 */
	String getCategory();

	/**
	 * Returns the subsystem the current producer is located in. we refer to your application
	 * as "the system". If you want to filter some parts of your system separately you should use
	 * the getSubsystem() method to separate them. Possible subsystems are: usermanagement,
	 * messaging... whatever. The getCategory() method should separate parts of the application
	 * horizontally, whether the getSubsystem() method should provide vertical separation.
	 * 
	 * @return the id of the subsystem the producer belongs to.
	 */
	String getSubsystem();
	
	
	boolean unregisterAfterSnapshot();
	

}