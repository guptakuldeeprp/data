package stats.core.dynamic;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import stats.core.inspection.CreationInfo;
import stats.core.inspection.Inspectable;
import stats.core.producer.StatsProducer;
import stats.core.stats.Stats;

//TODO: Use a stats factory to generate stats. Take the factory as an argument of the constructor
public class OnDemandStatsProducer<S extends Stats> implements StatsProducer<S>, Inspectable {

	private OnDemandStatsFactory<S> factory;

	private String category;

	private String producerId;

	private String subsystem;

	private CreationInfo creationInfo;
	
	private boolean unregisterAfterSnapshot;

	/**
	 * A cached stat list for faster access.
	 */
	private List<S> _cachedStatsList;
	/**
	 * A map where all stat and their ids (strings) are being stored.
	 */
	private final ConcurrentHashMap<String, S> stats;

	public OnDemandStatsProducer(String aProducerId, String aCategory, String aSubsystem, boolean aUnregisterAfterSnapshot,
			OnDemandStatsFactory<S> factory) {
		if (factory == null)
			throw new IllegalArgumentException("Null factory is not allowed.");

		category = aCategory;
		producerId = aProducerId;
		subsystem = aSubsystem;
		unregisterAfterSnapshot = aUnregisterAfterSnapshot;
		this.factory = factory;

		stats = new ConcurrentHashMap<String, S>();
		_cachedStatsList = new CopyOnWriteArrayList<S>();

		// setup the creation info for inspection
		Exception e = new Exception();
		e.fillInStackTrace();
		creationInfo = new CreationInfo(e.getStackTrace());
		
	}

	@Override
	public List<S> getStats() {
		return _cachedStatsList;
	}

	public S getStats(String name, boolean useCache) throws OnDemandStatsProducerException {
		
		
		S stat = useCache ? stats.get(name) : null;
		if (stat == null) {
			if (limitForNewEntriesReached())
				throw new OnDemandStatsProducerException("Limit reached");
			stat = factory.createStatsObject(name);
			S old = useCache ? stats.putIfAbsent(name, stat) : null;
			if (old == null) {
				_cachedStatsList.add(stat);
			} else {
				stat = old;
			}
		}
		return stat;

	}

	@Override
	public String getProducerId() {
		return producerId;
	}

	@Override
	public String getCategory() {
		return category;
	}

	@Override
	public String getSubsystem() {
		return subsystem;
	}

	/**
	 * The getStats method checked whether the limit is reached before creating
	 * a new stat object. Overwrite this function and return true if you want to
	 * limit the number of possible stored stats. Not limiting the stats can
	 * result in memory leak if someone can influence the stat names from the
	 * outside.
	 * 
	 * @return false
	 */
	protected boolean limitForNewEntriesReached() {
		return false;
	}

	@Override
	public CreationInfo getCreationInfo() {
		return creationInfo;
	}

	@Override
	public boolean unregisterAfterSnapshot() {
		return unregisterAfterSnapshot;
	}

}
