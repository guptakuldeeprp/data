package stats.core.dynamic;

public class OnDemandStatsProducerException extends Exception{

	public OnDemandStatsProducerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OnDemandStatsProducerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public OnDemandStatsProducerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OnDemandStatsProducerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
