package stats.core.dynamic;

import stats.core.stats.Stats;

public interface OnDemandStatsFactory<S extends Stats> {
	/**
	 * Creates a new stats object with given name.
	 *
	 * @param name
	 *            name of the stat object, may be a constant or method name.
	 * @return
	 */
	S createStatsObject(String name);
}
