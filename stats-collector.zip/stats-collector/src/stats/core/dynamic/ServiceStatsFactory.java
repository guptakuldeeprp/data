package stats.core.dynamic;

import stats.core.stats.ServiceStats;

public class ServiceStatsFactory implements OnDemandStatsFactory<ServiceStats> {

	@Override
	public ServiceStats createStatsObject(String name) {
		return new ServiceStats(name);
	}

}
