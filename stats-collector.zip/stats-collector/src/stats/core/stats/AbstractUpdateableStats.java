package stats.core.stats;

public abstract class AbstractUpdateableStats extends AbstractStats implements UpdateableStats{

	@Override
	public void update() {
		this.lastUpdated = System.nanoTime();		
	}

}
