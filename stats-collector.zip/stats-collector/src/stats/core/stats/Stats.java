package stats.core.stats;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.TimeUnit;

public interface Stats extends Serializable{
	
	long getLastUpdatedTime();
	
	long convertLastUpdatedTime(TimeUnit destUnit);
	
	String getValueByNameAsString(String valueName);
	
	List<String> getAvailableValueNames();
	
	String getName();
	
	boolean isEmpty();
	
}
