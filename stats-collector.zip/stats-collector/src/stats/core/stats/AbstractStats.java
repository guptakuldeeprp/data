package stats.core.stats;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

public abstract class AbstractStats implements Stats {

	protected static final String DEFAULT_NAME = "DefaultStats";

	protected static final TimeUnit DEFAULT_TIME_UNIT = TimeUnit.NANOSECONDS;

	protected static final long serialVersionUID = 1L;

	protected long lastUpdated;

	@Override
	public long getLastUpdatedTime() {
		return lastUpdated;
	}

	@Override
	public List<String> getAvailableValueNames() {
		return Collections.emptyList();
	}

	@Override
	public String getName() {
		return DEFAULT_NAME;
	}

	@Override
	public long convertLastUpdatedTime(TimeUnit destUnit) {
		return destUnit.convert(lastUpdated, DEFAULT_TIME_UNIT);
	}
	
	@Override
	public boolean isEmpty() {
		return true;
	}
}
