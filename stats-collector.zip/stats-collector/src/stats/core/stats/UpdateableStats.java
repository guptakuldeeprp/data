package stats.core.stats;

import stats.core.Updateable;

public interface UpdateableStats extends Stats, Updateable{

}
