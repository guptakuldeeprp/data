package stats.core.stats;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ServiceStats extends AbstractStats {

	private static final stats.core.dynamic.ServiceStatsFactory FACTORY = new stats.core.dynamic.ServiceStatsFactory();

	private String name;

	private String className;

	private String methodName;

	private long startTime;

	private long endTime;

	private static final List<String> VALUE_LIST = Collections.unmodifiableList(Arrays.asList("className",
			"methodName", "startTime", "endTime"));

	public ServiceStats(String name) {
		this.name = name;
	}

	public void addRequest() {
		startTime = System.nanoTime();
	}

	public void notifyError(Throwable e) {

	}

	public void notifyRequestFinished() {
		endTime = System.nanoTime();
	}

	public long getExecutionTime(TimeUnit unit) {
		return 0L;
	}

	public String getClassName() {
		return className;
	}

	public String getMethodName() {
		return methodName;
	}

	@Override
	public String getName() {
		return name;
	}
	
	public void setClassName(String className) {
		this.className = className;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	@Override
	public String getValueByNameAsString(String valueName) {
		if("className".equals(valueName))
			return className;
		if("methodName".equals(valueName))
			return methodName;
		if("startTime".equals(valueName))
			return "" + startTime;
		if("endTime".equals(valueName))
			return "" + endTime;
		return null;
	}
	
	@Override
	public List<String> getAvailableValueNames() {
		return VALUE_LIST;
	}

	public static void main(String[] args) {

	}

}
