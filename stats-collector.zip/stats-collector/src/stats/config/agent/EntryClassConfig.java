package stats.config.agent;

import org.configureme.annotations.Configure;

public class EntryClassConfig {
	
	@Configure
	private String name;
	 @Configure
	private String entryClassName;
	 @Configure
	private String entryMethodName;
	public String getEntryClassName() {
		return entryClassName;
	}
	public void setEntryClassName(String entryClassName) {
		this.entryClassName = entryClassName;
	}
	public String getEntryMethodName() {
		return entryMethodName;
	}
	public void setEntryMethodName(String entryMethodName) {
		this.entryMethodName = entryMethodName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "EntryClassConfig [name=" + name + ", entryClassName=" + entryClassName + ", entryMethodName="
				+ entryMethodName + "]";
	}
}
