package stats.config.agent;

import java.util.Arrays;

import org.configureme.annotations.Configure;
import org.configureme.annotations.ConfigureMe;

import com.google.gson.annotations.SerializedName;

@ConfigureMe(name = "testmonitoring-cfg")
public class TestMonitoringConfig {

	@Configure
	@SerializedName("@entryClassConfig")
	private EntryClassConfig entryClassConfig;
	@Configure
	private String[] classesToInclude;

	public String[] getClassesToInclude() {
		return classesToInclude;
	}

	public void setClassesToInclude(String[] classesToInclude) {
		this.classesToInclude = classesToInclude;
	}

	public EntryClassConfig getEntryClassConfig() {
		return entryClassConfig;
	}

	public void setEntryClassConfig(EntryClassConfig entryClassConfig) {
		this.entryClassConfig = entryClassConfig;
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer("TestMonitoringConfig{");
		sb.append("entryClassConfig=").append(entryClassConfig == null ? "null" : entryClassConfig.toString());
		sb.append(", classesToInclude=").append(
				classesToInclude == null ? "null" : Arrays.asList(classesToInclude).toString());
		sb.append('}');
		return sb.toString();
	}

}
