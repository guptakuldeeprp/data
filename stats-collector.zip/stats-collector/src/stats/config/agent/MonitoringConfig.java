package stats.config.agent;

import java.util.Arrays;

import org.configureme.annotations.Configure;

import org.configureme.annotations.ConfigureMe;

import com.google.gson.annotations.SerializedName;

@ConfigureMe(name = "monitoring-cfg")
public class MonitoringConfig {

	@Configure
	@SerializedName("@entryClassConfig")
	private EntryClassConfig entryClassConfig;

	@Configure
	@SerializedName("@monitoringClassConfig")
	private MonitoringClassConfig[] monitoringClassConfig;

	@Configure
	private String[] classesToInclude;

	public MonitoringClassConfig[] getMonitoringClassConfig() {
		return monitoringClassConfig;
	}

	public void setMonitoringClassConfig(MonitoringClassConfig[] monitoringClassConfig) {
		this.monitoringClassConfig = monitoringClassConfig;
	}

	public String[] getClassesToInclude() {
		return classesToInclude;
	}

	public void setClassesToInclude(String[] classesToInclude) {
		this.classesToInclude = classesToInclude;
	}

	public EntryClassConfig getEntryClassConfig() {
		return entryClassConfig;
	}

	public void setEntryClassConfig(EntryClassConfig entryClassConfig) {
		this.entryClassConfig = entryClassConfig;
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer("LoadTimeMonitoringConfig{");
		sb.append("monitoringClassConfig=").append(
				monitoringClassConfig == null ? "null" : Arrays.asList(monitoringClassConfig).toString());
		sb.append(", classesToInclude=").append(
				classesToInclude == null ? "null" : Arrays.asList(classesToInclude).toString());
		sb.append('}');
		return sb.toString();
	}

}
