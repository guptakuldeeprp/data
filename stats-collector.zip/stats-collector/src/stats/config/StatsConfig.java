package stats.config;



import org.configureme.annotations.Configure;
import org.configureme.annotations.ConfigureMe;

import stats.config.plugin.PluginsConfig;

import com.google.gson.annotations.SerializedName;

@ConfigureMe(name="stats-cfg")
public class StatsConfig {
	
	@Configure
	@SerializedName("@pluginsConfig")
	private PluginsConfig pluginsConfig = new PluginsConfig();

	public PluginsConfig getPluginsConfig() {
		return pluginsConfig;
	}

	public void setPluginsConfig(PluginsConfig pluginsConfig) {
		this.pluginsConfig = pluginsConfig;
	}

	@Override
	public String toString() {
		return "StatsConfig [pluginsConfig=" + pluginsConfig + "]";
	}

}
