package stats.config.plugin;



import java.util.Arrays;

import org.configureme.annotations.Configure;
import org.configureme.annotations.ConfigureMe;

@ConfigureMe
public class PluginsConfig {
	@Configure private PluginConfig[] plugins;

	public PluginConfig[] getPlugins() {
		return plugins;
	}

	public void setPlugins(PluginConfig[] plugins) {
		this.plugins = plugins;
	}

	@Override
	public String toString() {
		return "PluginsConfig [plugins=" + Arrays.toString(plugins) + "]";
	}

}
