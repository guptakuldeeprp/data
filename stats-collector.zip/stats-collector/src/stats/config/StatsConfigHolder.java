package stats.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.configureme.ConfigurationManager;

public enum StatsConfigHolder {

	INSTANCE;

	private final Log logger = LogFactory.getLog(StatsConfigHolder.class);
	private volatile StatsConfig configuration;

	/**
	 * Creates a new configuration holder.
	 */
	private StatsConfigHolder() {

		configuration = createDefaultConfiguration();
		try {
			// now let configuration override some config options.
			ConfigurationManager.INSTANCE.configure(configuration);
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("No configuration found. Working with default configuration.");
			//logger.info("No configuration found. Working with default configuration.");
		}
	}

	/**
	 * Creates default configuration in case there is no stats-cfg.json supplied
	 * with the project. It's prefer to have all default configuration at one
	 * place to have a better overview, instead of having the default values in
	 * the objects themselves. 
	 * 
	 * @return
	 */
	//TODO: Implement the method body to create a default configuration.
	private static StatsConfig createDefaultConfiguration() {
		return new StatsConfig();
	}
	
	/**
	 * Returns current configuration.
	 * @return
	 */
	public static StatsConfig getConfiguration(){
		return INSTANCE.configuration;
	}

}
