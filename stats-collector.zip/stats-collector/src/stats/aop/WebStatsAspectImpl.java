package stats.aop;

import java.lang.reflect.InvocationTargetException;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.configureme.ConfigurationManager;

import stats.config.agent.MonitoringClassConfig;
import stats.config.agent.MonitoringConfig;
import stats.core.dynamic.OnDemandStatsProducer;
import stats.core.dynamic.ServiceStatsFactory;
import stats.core.stats.ServiceStats;
import stats.trace.CurrentlyTracedCall;
import stats.trace.RunningTraceContainer;
import stats.trace.TraceStep;
import stats.trace.TracedCall;

@Aspect
public abstract class WebStatsAspectImpl extends AbsbtractStatsAspect {

	/**
	 * Factory constant is needed to prevent continuous reinstantiation of
	 * ServiceStatsFactory objects.
	 */
	private static final ServiceStatsFactory FACTORY = new ServiceStatsFactory();

	// private TestMonitoringConfig monitoringConfig = new
	// TestMonitoringConfig();

	private MonitoringConfig monitoringConfig = new MonitoringConfig();

	// abstract pointcut: no expression is defined
	@Pointcut
	abstract void monitoredMethod();

	protected WebStatsAspectImpl() {
		// ConfigurationManager.INSTANCE.configure(monitoringConfig);
		ConfigurationManager.INSTANCE.configure(monitoringConfig);
	}

	@Around(value = "monitoredMethod()")
	public Object doProfilingMethod(ProceedingJoinPoint pjp) throws Throwable {

		MonitoringClassConfig method = getMonitoringConfig(pjp.getSignature().getDeclaringTypeName());

		return doProfiling(pjp, method.getProducerId(), method.getSubsystem(), method.getCategory());

		// return doProfiling(pjp,
		// pjp.getSignature().getDeclaringType().getName(),
		// pjp.getSignature().getName(), pjp
		// .getSignature().getName());
	}

	/*  */
	private Object doProfiling(ProceedingJoinPoint pjp, String aProducerId, String aSubsystem, String aCategory)
			throws Throwable {

		final Object[] args = pjp.getArgs();
		final String method = pjp.getSignature().getName();

		String caseName = pjp.getSignature().getDeclaringType() + "." + pjp.getSignature().getName();

		ServiceStats methodStats = null;
		TraceStep currentStep = null;
		CurrentlyTracedCall currentTrace = null;

		OnDemandStatsProducer<ServiceStats> producer = getProducer(pjp, aProducerId, aCategory, aSubsystem, false, true,
				FACTORY);
		// System.out.println("got producer: " + producer);
		String producerId = producer.getProducerId();

		methodStats = producer.getStats(caseName, false);
		methodStats.setClassName(pjp.getSignature().getDeclaringType().getName());
		methodStats.setMethodName(pjp.getSignature().getName());

		if (methodStats != null) {
			methodStats.addRequest();
		}

		TracedCall aRunningTrace = RunningTraceContainer.getCurrentlyTracedCall();
		currentTrace = aRunningTrace.callTraced() ? (CurrentlyTracedCall) aRunningTrace : null;
		if (currentTrace != null) {
			StringBuilder call = new StringBuilder(producerId).append('.').append(method).append("(");
			if (args != null && args.length > 0) {
				for (int i = 0; i < args.length; i++) {
					call.append(args[i]);
					if (i < args.length - 1) {
						call.append(", ");
					}
				}
			}
			call.append(")");

			currentStep = currentTrace.startStep(call.toString(), producer);
		}

		long startTime = System.nanoTime();
		Object ret = null;
		try {
			ret = pjp.proceed();
			return ret;
		} catch (InvocationTargetException e) {

			if (methodStats != null) {
				methodStats.notifyError(e);
			}
			// System.out.println("exception of class: "+e.getCause()+" is thrown");
			if (currentStep != null) {
				currentStep.setAborted();
			}
			throw e.getCause();
		} catch (Throwable t) {

			if (methodStats != null) {
				methodStats.notifyError(t);
			}
			if (currentStep != null) {
				currentStep.setAborted();
			}
			throw t;
		} finally {
			long exTime = System.nanoTime() - startTime;

			if (methodStats != null) {
				methodStats.notifyRequestFinished();
			}
			if (currentStep != null) {
				currentStep.setDuration(exTime);
				try {
					currentStep.appendToCall(" = " + ret);
				} catch (Throwable t) {
					currentStep.appendToCall(" = ERR: " + t.getMessage() + " (" + t.getClass() + ")");
				}
			}
			if (currentTrace != null) {
				currentTrace.endStep();
			}

			// Make everything null to help gc
			/*
			 * methodStats = null; currentTrace = null; currentStep = null;
			 * aRunningTrace = null;
			 */

		}

	}

	private boolean isEntryMethodCall(ProceedingJoinPoint pjp) {
		return pjp.getSignature().getDeclaringType().getName()
				.equals(monitoringConfig.getEntryClassConfig().getEntryClassName())
				&& pjp.getSignature().getName().equals(monitoringConfig.getEntryClassConfig().getEntryMethodName());
	}

	private MonitoringClassConfig getMonitoringConfig(String declaringTypeName) {
		for (MonitoringClassConfig monitoringClassConfig : monitoringConfig.getMonitoringClassConfig()) {
			if (monitoringClassConfig.patternMatch(declaringTypeName)) {
				return monitoringClassConfig;
			}
		}
		return new MonitoringClassConfig();
	}

}
