package stats.aop;

import org.aspectj.lang.ProceedingJoinPoint;

import stats.core.dynamic.OnDemandStatsFactory;
import stats.core.dynamic.OnDemandStatsProducer;
import stats.core.producer.StatsProducer;
import stats.core.stats.Stats;
import stats.registry.ProducerRegistryFactory;

//TODO: Comment this class. Identify whether caching producers at this level makes any sense?
public class AbsbtractStatsAspect<S extends Stats> {

	/**
	 * Map with created producers.
	 */
	// private ConcurrentMap<String, OnDemandStatsProducer<S>> producers = new
	// ConcurrentHashMap<String, OnDemandStatsProducer<S>>();

	/**
	 * Returns the producer for the given pjp and producerId. Registers the
	 * producer in the registry if it's not already registered.
	 * 
	 * @param pjp
	 *            the pjp is used to obtain the producer id automatically if
	 *            it's not submitted.
	 * @param aProducerId
	 *            submitted producer id, used if configured in aop.
	 * @param aCategory
	 *            submitted category.
	 * @param aSubsystem
	 *            submitted subsystem.
	 * @param withMethod
	 *            if true the name of the method will be part of the
	 *            automatically generated producer id.
	 * @return
	 */
	protected OnDemandStatsProducer<S> getProducer(ProceedingJoinPoint pjp, String aProducerId, String aCategory,
			String aSubsystem, boolean withMethod, boolean unregisterAfterSnapshot, OnDemandStatsFactory<S> factory) {
		String producerId = null;
		if (aProducerId != null && aProducerId.length() > 0) {
			producerId = aProducerId;
		} else {
			producerId = pjp.getSignature().getDeclaringTypeName();
			/*
			 * try { producerId =
			 * producerId.substring(producerId.lastIndexOf('.') + 1); } catch
			 * (RuntimeException ignored) { ignored }
			 */
		}

		if (withMethod)
			producerId += "." + pjp.getSignature().getName();

		OnDemandStatsProducer<S> producer = new OnDemandStatsProducer(producerId, getCategory(aCategory),
				getSubsystem(aSubsystem), unregisterAfterSnapshot, factory);

		// TODO: Handle the case of ClassCastException
		return (OnDemandStatsProducer<S>) ProducerRegistryFactory.getProducerRegistryInstance().registerProducer(
				producer);

		// OnDemandStatsProducer<S> producer = producers.get(producerId);
		// if (producer == null) {
		//
		// producer = new OnDemandStatsProducer(producerId,
		// getCategory(aCategory), getSubsystem(aSubsystem), factory);
		// OnDemandStatsProducer<S> p = producers.putIfAbsent(producerId,
		// producer);
		// if (p == null) {
		// ProducerRegistryFactory.getProducerRegistryInstance().registerProducer(producer);
		// } else {
		// producer = p;
		// }
		// }
		// return producer;

	}
	
	protected void unregisterProducer(OnDemandStatsProducer<S> producer) {
		ProducerRegistryFactory.getProducerRegistryInstance().unregisterProducer(producer);
	}

	/**
	 * Returns the category to use for the producer registration.
	 * 
	 * @param proposal
	 * @return
	 */
	public String getCategory(String proposal) {
		return proposal == null || proposal.length() == 0 ? "annotated" : proposal;
	}

	/**
	 * Returns the subsystem for registration.
	 * 
	 * @param proposal
	 * @return
	 */
	public String getSubsystem(String proposal) {
		return proposal == null || proposal.length() == 0 ? "default" : proposal;
	}

	public void reset() {
		// producers.clear();
	}

}
