package stats.javaagent;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.NotFoundException;

import org.configureme.ConfigurationManager;

import stats.config.StatsConfig;
import stats.config.StatsConfigHolder;
import stats.config.agent.TestMonitoringConfig;

public class StatsAgent {

	private static TestMonitoringConfig monitoringConfig = new TestMonitoringConfig();
	private static StatsConfig statsConfig;
	private static boolean intstrument = true;
	private static String useCaseName = "testcase";

	public static void premain(String agentArgs, Instrumentation inst) {
		try {
			statsConfig = StatsConfigHolder.getConfiguration();
			ConfigurationManager.INSTANCE.configure(monitoringConfig);
			System.out.println("statsConfig: " + statsConfig);
			System.out.println("monitoringConfig: " + monitoringConfig);
			inst.addTransformer(new DurationTransformer());
		} catch (Throwable e) {
			intstrument = false;
			System.err.println("Error in initialization/premain of agent. No instrumentation will be performed. ");
			e.printStackTrace();
		}
	}

	public static class DurationTransformer implements ClassFileTransformer {

		@Override
		public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
				ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
			byte[] bytecode = classfileBuffer;
			if (intstrument) {
				CtClass cc = null;
				try {
					ClassPool cp = ClassPool.getDefault();
					cp.importPackage("stats");
					if (className.equals(monitoringConfig.getEntryClassConfig().getEntryClassName())) {
						cc = cp.makeClass(new ByteArrayInputStream(classfileBuffer));
						CtMethod cm = cc.getDeclaredMethod(monitoringConfig.getEntryClassConfig().getEntryMethodName());
						cm.insertBefore("{ stats.trace.RunningTraceContainer.startTracedCall(" + useCaseName + "); }");
						cm.insertAfter(
								"{ stats.core.snapshot.SnapshotRepository.getInstance().takeSnapshot(); stats.trace.RunningTraceContainer.endTrace(); }",
								true);
					} else if (containsClassToInclude(className)) {
						System.out.println("containsClassToInclude passed..");
						// cc = cp.get( "com.zycus.agent.demo.Hello");
						cc = cp.makeClass(new ByteArrayInputStream(classfileBuffer));
						CtField factoryField = CtField
								.make("private static final stats.core.dynamic.ServiceStatsFactory FACTORY = new stats.core.dynamic.ServiceStatsFactory();",
										cc);
						cc.addField(factoryField);
						for (CtMethod cm : cc.getDeclaredMethods()) {
							surroundMethodBody(cp, cc, cm);
						}
						/*
						 * CtField watchField = CtField.make(
						 * "public com.zycus.agent.demo.Stopwatch stopwatch = new com.zycus.agent.demo.Stopwatch();"
						 * , cc); cc.addField(watchField); CtMethod m =
						 * cc.getDeclaredMethod("say");
						 * m.insertBefore("{ stopwatch.start(); }");
						 * m.insertAfter(
						 * "{ stopwatch.stop(); System.out.println(\"The reading is: \" + stopwatch); }"
						 * );
						 */

					}
					bytecode = cc == null ? bytecode : cc.toBytecode();
				} catch (NotFoundException e) {

					e.printStackTrace();
				} catch (CannotCompileException e) {

					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return bytecode;
		}

	}

	private static void surroundMethodBody(ClassPool cp, CtClass cc, CtMethod cm) throws CannotCompileException, NotFoundException {

		String className = cc.getName();
		String methodName = cm.getName();
		String catName = cm.getName();
		StringBuilder builder = new StringBuilder();
		
		CtClass ssc = cp.get("stats.core.stats.ServiceStats");	
		cm.addLocalVariable("methodStats", ssc);
		
		CtClass etype = cp.get("java.lang.Throwable");
		cm.addCatch("{methodStats.notifyError(); throw t;}", etype, "t");
		
		builder.append("{ ");
		builder.append(" stats.core.dynamic.OnDemandStatsProducer producer = new stats.core.dynamic.OnDemandStatsProducer(\"" + className + "\",\"" + catName + "\",\"" + methodName + "\",FACTORY);");
		builder.append(" String producerId = producer.getProducerId();");
		builder.append(" methodStats = (stats.core.stats.ServiceStats) producer.getStats(\"" + methodName + "\");");
		builder.append(" methodStats.addRequest();");
		builder.append(" stats.trace.TracedCall aRunningTrace = stats.trace.RunningTraceContainer.getCurrentlyTracedCall();");
		builder.append(" stats.trace.TraceStep currentStep = null;");
		builder.append(" stats.trace.CurrentlyTracedCall currentTrace = aRunningTrace.callTraced() ? (stats.trace.CurrentlyTracedCall) aRunningTrace : null;");
		builder.append(" String call = producerId + '.' + \"" + methodName + "\";");
		builder.append(" currentStep = currentTrace.startStep(call.toString(), producer);");
		builder.append(" }");
		System.out.println("insert before: ");
		System.out.println(builder.toString());
		
		cm.insertBefore(builder.toString());
		cm.insertAfter("{methodStats.notifyRequestFinished();}", true);

	}

	private static String getPostMethodBody() {
		return null;
	}

	private static boolean containsClassToInclude(String className) {
		String[] classesToExclude = monitoringConfig.getClassesToInclude();
		for (String classToExclude : classesToExclude) {
			if (className.matches(classToExclude.replace("/", "."))) {
				System.out.println(className + " is required to be included");
				return true;
			}
		}
		System.out.println(className + " is not required to be included");
		return false;
	}

	// public static void main(String[] args) {
	// StringBuilder builder = new StringBuilder();
	// String className = "com.zycus.agent.demo.Test";
	// String catName = "catName";
	// String methodName = "test";
	// builder.append("{ ");
	// builder.append("stats.core.dynamic.OnDemandStatsProducer<stats.core.stats.ServiceStats> producer = new stats.core.dynamic.OnDemandStatsProducer<stats.core.stats.ServiceStats>(\""
	// + className + "\",\"" + catName + "\",\"" + methodName + "\",FACTORY);");
	// builder.append("String producerId = producer.getProducerId();");
	// builder.append("stats.core.stats.ServiceStats methodStats = producer.getStats(\""
	// + methodName + "\");");
	// builder.append("methodStats.addRequest();");
	// builder.append("stats.trace.TracedCall aRunningTrace = stats.trace.RunningTraceContainer.getCurrentlyTracedCall();");
	// builder.append("stats.trace.TraceStep currentStep = null;");
	// builder.append("stats.trace.CurrentlyTracedCall currentTrace = aRunningTrace.callTraced() ? (CurrentlyTracedCall) aRunningTrace : null;");
	// builder.append("String call = producerId + '.' + " + methodName + ";");
	// builder.append("currentStep = currentTrace.startStep(call.toString(), producer);");
	// builder.append(" }");
	// System.out.println(builder.toString());
	// }

}
