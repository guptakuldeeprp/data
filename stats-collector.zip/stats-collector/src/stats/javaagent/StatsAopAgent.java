package stats.javaagent;

import java.io.File;
import java.io.IOException;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;
import java.util.jar.JarFile;

import org.aspectj.weaver.loadtime.ClassPreProcessorAgentAdapter;
import org.configureme.ConfigurationManager;

import stats.config.agent.MonitoringConfig;

public class StatsAopAgent implements java.lang.instrument.ClassFileTransformer {

	private org.aspectj.weaver.loadtime.ClassPreProcessorAgentAdapter classPreProcessorAgentAdapter = new ClassPreProcessorAgentAdapter();
	// private TestMonitoringConfig loadTimeMonitoringConfig = new
	// TestMonitoringConfig();
	private MonitoringConfig loadTimeMonitoringConfig = new MonitoringConfig();
	private static final String SYSTEM_CP_PREFIX = "C:\\apache-tomcat-8.0.32\\apache-tomcat-8.0.32\\stats";
	private static final String LIB_CP_PREFIX = "C:\\apache-tomcat-8.0.32\\apache-tomcat-8.0.32\\lib";
	private static final String[] CP_PREFIX = new String[] { SYSTEM_CP_PREFIX};

	/**
	 * JVM hook to statically load the javaagent at startup.
	 * <p/>
	 * After the Java Virtual Machine (JVM) has initialized, the premain method
	 * will be called. Then the real application main method will be called.
	 *
	 * @param args
	 * @param inst
	 * @throws Exception
	 */
	public static void premain(String args, Instrumentation inst) {
		System.out.println("Adding to classpath jars from " + SYSTEM_CP_PREFIX);
		for (String dirName : CP_PREFIX) {
			File dir = new File(dirName);
			for (File jarFile : dir.listFiles()) {
				try {
					inst.appendToSystemClassLoaderSearch(new JarFile(jarFile));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		StatsAopAgent aspectTransformationAgent = new StatsAopAgent();
		ConfigurationManager.INSTANCE.configure(aspectTransformationAgent.loadTimeMonitoringConfig);
		inst.addTransformer(aspectTransformationAgent);
	}

	/**
	 * JVM hook to dynamically load javaagent at runtime.
	 * <p/>
	 * The agent class may have an agentmain method for use when the agent is
	 * started after VM startup.
	 *
	 * @param args
	 * @param inst
	 * @throws Exception
	 */
	public static void agentmain(String args, Instrumentation inst) throws Exception {
		inst.addTransformer(new StatsAopAgent());

		inst.appendToSystemClassLoaderSearch(new JarFile(new File("")));
	}

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
			ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
		if (!containsClassToInclude(className))
			return classfileBuffer;
		return classPreProcessorAgentAdapter.transform(loader, className, classBeingRedefined, protectionDomain,
				classfileBuffer);
	}

	private boolean containsClassToInclude(String className) {
		String[] classesToExclude = loadTimeMonitoringConfig.getClassesToInclude();
		for (String classToExclude : classesToExclude) {
			if (className.matches(classToExclude.replace("/", "."))) {
				return true;
			}
		}
		return false;
	}

}
