package stats.utils;

import java.net.InetAddress;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class NetUtils {
	private static Log log = LogFactory.getLog(NetUtils.class);

	public static final String getComputerName() {
		try {
			InetAddress address = InetAddress.getLocalHost();
			return address.getHostName();
		} catch (Exception e) {
			log.warn("getComputerName", e);
		}
		return null;
	}

	public static final String getShortComputerName() {
		String fullName = getComputerName();
		if (fullName == null)
			return fullName;
		int dotIndex = fullName.indexOf(46);
		return ((dotIndex == -1) ? fullName : fullName.substring(0, dotIndex));
	}

	public static void main(String[] args) {
		System.out.println(getShortComputerName());
	}
}