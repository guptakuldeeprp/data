package stats.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;


public class JsonHelper {

	private static ObjectMapper objMapper = new ObjectMapper();

	static {
		objMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		objMapper.enable(SerializationFeature.INDENT_OUTPUT);
		objMapper.enable(SerializationFeature.WRITE_NULL_MAP_VALUES);
		objMapper.enable(SerializationFeature.WRITE_EMPTY_JSON_ARRAYS);
		objMapper.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
		objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	/**
	 * Instantiates a new json helper. You must be sure you know what you are
	 * doing
	 *
	 * @param sConfig
	 *            the SerializationConfig
	 * @param dConfig
	 *            the DeserializationConfig
	 */
	// public JsonHelper(SerializationConfig sConfig, DeserializationConfig
	// dConfig) {
	// if (sConfig != null)
	// objMapper.setConfig(sConfig);
	// if (dConfig != null)
	// objMapper.setConfig(dConfig);
	// }

	public static String getJsonString(Object o) {

		String json = null;
		try {
			json = objMapper.writeValueAsString(o);
		} catch (JsonProcessingException e) {
			throw new JsonException(e.getMessage(), e);

		}

		return json;
	}

	public static byte[] getJsonBytes(Object o) {
		byte[] json = null;
		try {
			json = objMapper.writeValueAsBytes(o);
		} catch (JsonProcessingException e) {
			throw new JsonException(e.getMessage(), e);

		}

		return json;
	}

	public static void getJson(Object o, Writer w) {
		try {
			objMapper.writeValue(w, o);
		} catch (JsonGenerationException e) {
			throw new JsonException(e.getMessage(), e);
		} catch (JsonMappingException e) {
			throw new JsonException(e.getMessage(), e);
		} catch (IOException e) {
			throw new JsonException(e.getMessage(), e);
		}
	}
	
	public static JsonNode valueToTree(Object o)
	{
		return objMapper.valueToTree(o);
	}
	
	public static JsonNode loadJsonTree(byte[] bytes) throws JsonProcessingException, IOException{
		//JsonFactory factory = new JsonFactory();
		//JsonParser jp = null;
		return objMapper.readTree(bytes);
	}
	
	public static JsonNode loadJsonTree(InputStream is) throws IOException {
		//JsonFactory factory = new JsonFactory();
		//JsonParser jp = null;
		return objMapper.readTree(is);
	}
	
	public static Map<String, String> loadJsonMap(InputStream is) throws IOException {
		return loadJsonMap(is, new HashMap<String, String>());
	}
	
	public static Map<String, String> loadJsonMap(InputStream is, Map<String, String> map) throws IOException {
		JsonNode jsonNode = objMapper.readTree(is);
		Iterator<Entry<String, JsonNode>> fieldsItr = jsonNode.fields();
		while(fieldsItr.hasNext()) {
			Entry<String, JsonNode> entry = fieldsItr.next();
			map.put(entry.getKey(), entry.getValue().textValue());
		}
		
		return map;
	}
	
	public static <T> Set<T> loadJson(InputStream is, Class<T> type) throws IOException {
		JsonFactory factory = new JsonFactory();
		JsonParser jp = null;
		Set<T> set = Collections.checkedSet(new HashSet(), type);
		
		try {
			
			jp = factory.createParser(is);			
			MappingIterator<T> itr = objMapper.readValues(jp, type);
			while (itr.hasNext()) {
				set.add(itr.next());
				//create(key, itr.next(), cacheQueries);
			}
		} catch (JsonParseException e) {
			throw new JsonException("Could not parse Query from the given JSON stream :: " + e.getMessage(),
					e);
		} catch (IOException e) {
			throw e;
		} finally {
			if (jp != null)
				jp.close();
		}
		
		return set;
	}
	// objMapper.
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		System.out.println(loadJsonMap(new FileInputStream("C:/Users/kuldeep.gupta/Desktop/querymap.txt")));
	}

}
