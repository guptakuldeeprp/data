package stats.trace;



public class RunningTraceContainer {
	
	/**
	 * Currently running use case.
	 */
	private static ThreadLocal<TracedCall> currentlyTracedCall = new ThreadLocal<TracedCall>(){
		protected synchronized TracedCall initialValue(){
			return NoTracedCall.INSTANCE;
		}
	};
	
	public static TracedCall getCurrentlyTracedCall(){
		return currentlyTracedCall.get();
	}
	
	public static void startTracedCall(String name){
		currentlyTracedCall.set(new CurrentlyTracedCall(name));
	}
	
	public static void setCurrentlyTracedCall(TracedCall aTracedCall){
		currentlyTracedCall.set(aTracedCall);
	}
	
	public static TracedCall endTrace(){
		TracedCall last = getCurrentlyTracedCall();
		setCurrentlyTracedCall(NoTracedCall.INSTANCE);
		return last;
	}
	
	/**
	 * This is a special method for web applications to cleanup the ThreadLocals.
	 */
	public static void cleanup(){
		currentlyTracedCall.remove();
	}
	
	/**
	 * Returns true if there is currently a use-case recorded.
	 * @return
	 */
	public static boolean isTraceRunning(){
		return currentlyTracedCall.get().callTraced();
	}
}
