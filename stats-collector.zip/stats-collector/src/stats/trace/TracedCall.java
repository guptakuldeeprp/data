package stats.trace;


public interface TracedCall {
	/**
	 * Returns true if there is currently a running use case. In fact, if true is returned, one can safely assume 
	 * that the implementation of this interface one is dealing with is ExistingRunningUseCase. Otherwise its NoRunningUseCase.
	 * @return
	 * @see CurrentlyTracedCall
	 * @see NoTracedCall
	 */
	boolean callTraced();
}