package stats.trace;

import java.io.Serializable;

import stats.core.producer.StatsProducer;

public class CurrentlyTracedCall implements TracedCall, Serializable {

	/**
	 * SerialVersionID.
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Name of the call.
	 */
	private String name;
	/**
	 * Root step of the call.
	 */
	private TraceStep root = new TraceStep("");
	/**
	 * Current step in the call.
	 */
	private TraceStep current;
	/**
	 * Creation timestamp.
	 */
	private long created;

	/**
	 * Creates a new CurrentlyTracedCall.
	 * 
	 * @param aName
	 */
	public CurrentlyTracedCall(String aName) {
		name = aName;
		current = root;
		created = System.currentTimeMillis();
	}

	@Override
	public boolean callTraced() {
		return true;
	}

	@Override
	public String toString() {
		return "CurrentlyTracedCall: " + name;
	}

	public String toDetails() {
		return toString() + ": \n" + root.toDetails(1);
	}

	/**
	 * Creates a new sub step in current call.
	 */
	public TraceStep startStep(String call, StatsProducer producer) {
		TraceStep last = current;

		current = new TraceStep(call, producer);
		// it actually happened, we are still investigating why, but this fix
		// should at least prevent the NPE for now.
		if (last != null)
			last.addChild(current);
		return current;
	}

	/**
	 * Creates a new sub step in current call.
	 */
	@Deprecated
	public TraceStep startStep(String call) {
		return startStep(call, null);
	}

	public void endStep() {
		current = current.getParent();
	}

	public String getTrace() {
		return root.generateTrace();
	}

	public String getName() {
		return name;
	}

	public long getCreated() {
		return created;
	}

	public TraceStep getRootStep() {
		return root;
	}

	/**
	 * Returns the first step..
	 * 
	 * @return
	 */
	public TraceStep getFirstStep() {
		return root.getChildren().get(0);
	}

	public TraceStep getLastStep() {
		return root.getLastStep();
	}

	public int getNumberOfSteps() {
		return root.getNumberOfIncludedSteps();
	}

	public TraceStep getCurrentStep() {
		return current;
	}
}
