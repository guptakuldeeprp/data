package stats.trace;

/**
 * A null object implementation of the RunningUseCase. Used to prevent null
 * checks in surrounding code.
 *
 */
public enum NoTracedCall implements TracedCall {
	/**
	 * Instance, the one and only.
	 */
	INSTANCE;

	@Override
	public String toString() {
		return "NoTracedCall";
	}

	@Override
	public boolean callTraced() {
		return false;
	}
}